<?php
/*
 * Copyright notice
 * (c) 1998-2018 Limbas GmbH(support@limbas.org)
 * All rights reserved
 * This script is part of the LIMBAS project. The LIMBAS project is free software; you can redistribute it and/or modify it on 2 Ways:
 * Under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
 * Or
 * In a Propritary Software Licence http://limbas.org
 * The GNU General Public License can be found at http://www.gnu.org/copyleft/gpl.html.
 * A copy is found in the textfile GPL.txt and important notices to the license from the author is found in LICENSE.txt distributed with these scripts.
 * This script is distributed WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 * This copyright notice MUST APPEAR in all copies of the script!
 * Version 3.5
 */

/*
 * ID:
 */

if($BODYHEADER){
	if($LINK["icon_url"][$LINK_ID[$action]]){
		$BODYHEADER = "<i class=\"lmb-icon {$LINK["icon_url"][$LINK_ID[$action]]}\" align=\"absmiddle\" height=16></i>&nbsp;&nbsp;".$BODYHEADER;
	}
	echo "<script language=\"JavaScript\">\n";
	echo "var val='";

	echo $BODYHEADER;
	if($LINK["help_url"][$LINK_ID[$action]]){echo "<div style=\"position:absolute;top:10px;right:15px;\"><a href=\"".$LINK["help_url"][$LINK_ID[$action]]."\" target=\"new\"><i class=\"lmb-icon lmb-help\"></i></a></div>";}

	echo "';\n";
    $pageTitleText = str_replace(array("\xC2\xA0", "\xA0"), "", trim(strip_tags(html_entity_decode($BODYHEADER)))); // replace non-breaking whitespaces
    $pageTitle = $umgvar['page_title'] ? sprintf($umgvar['page_title'], $pageTitleText) : $pageTitleText;
	echo "if(top.main_top && top.main_top.document.getElementById('main_top_value')){top.main_top.document.getElementById('main_top_value').innerHTML = val;top.document.title='$pageTitle';}\n";
	echo "</script>\n";
}elseif($BODYHEADER != "0"){
	echo "<script language=\"JavaScript\">\n";
	echo "if(top.main_top && top.main_top.document.getElementById('main_top_value')){\n
	if(top.main_top.document.getElementById('main_top_value')){\n
	top.main_top.document.getElementById('main_top_value').innerHTML = '';\n
	}\n
	}\n";
	echo "</script>\n";
}

?>