<?php
class LimbasKunden extends LimbasRecord
{
	public function __construct($attributes=null)
	{
		parent::__construct('Kunden', $attributes);
	}
	
	public static function createModel($attributes=null)
	{
		return parent::model('Kunden', $attributes);
	}
}