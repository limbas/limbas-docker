

function myExt_openAqElement(el){
	pel = el.parentNode.nextSibling.firstChild.lastChild;
	if(pel.style.display == 'none'){
		$(pel).show(400,function(){
			var tagid = $(this);
			var tagid = pel.lastChild.id.split('_');
			lmb_syncTable(tagid[1]+'_'+tagid[2]);
		});
	}else{
		$(pel).hide(400);
	}
}

function MyExt_aqWfl_ShowEl(ellist){
	var els = ellist.split(",");

	for (var key in els){
		if(el = document.getElementById('element'+els[key])){
			el.style.display = '';
		}
	}
}

function MyExt_aqWfl_MarkAct(ellist){
	var els = ellist.split(",");

	for (var key in els){
		if(document.getElementById('element'+els[key])){
			$('#element'+els[key]).append("<img src='EXTENSIONS/css/check.png' style='position:absolute;top:-5px;right:-10px;'>");
		}
	}
}

function MyExt_aqWfl_MarkAlert(ellist){
	var els = ellist.split(",");

	for (var key in els){
		if(document.getElementById('element'+els[key])){
			$('#element'+els[key]).append("<img src='EXTENSIONS/css/alert.png' style='position:absolute;top:-2px;right:-9px;'>");
		}
	}
}


function MyExt_sendTask(par){
	
	if(par){
		document.getElementById("myExtForms").innerHTML = "<input type='hidden' name='myExt_sendTask' value="+par+">";
	}

	send_form(1);
}

function MyExt_showDialog(elname){

	if($("#"+elname).hasClass('ui-dialog-content')){
		$("#"+elname).dialog('open');
	}else{
	
	$("#"+elname).css({'position':'relative','left':'0','top':'0'}).dialog({
		width: $("#"+elname).width(),
		height: $("#"+elname).height(),
		resizable: false,
		modal: true,
		zIndex: $("#"+elname).zIndex(),
		appendTo: "#form1"
//open: function( event, ui ) {
//		$(this).parent().appendTo("form[name='form1']")
//		}

	});
	
	}
}
