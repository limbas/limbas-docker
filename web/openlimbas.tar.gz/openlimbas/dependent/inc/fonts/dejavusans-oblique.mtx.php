<?php
$name='DejaVuSans-Oblique';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 68,
  'FontBBox' => '[-1016 -356 1659 1068]',
  'ItalicAngle' => -11.0,
  'StemV' => 87.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile='inc/fonts/DejaVuSans-Oblique.ttf';
$originalsize=512140;
$fontkey='dejavu sansI';
?>