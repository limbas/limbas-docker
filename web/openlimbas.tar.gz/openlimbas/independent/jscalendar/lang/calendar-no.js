// ** I18N
Calendar._DN = new Array
("S�ndag",
 "Mandag",
 "Tirsdag",
 "Onsdag",
 "Torsdag",
 "Fredag",
 "L�rdag",
 "S�ndag");
Calendar._MN = new Array
("Januar",
 "Februar",
 "Mars",
 "April",
 "Mai",
 "Juni",
 "Juli",
 "August",
 "September",
 "Oktober",
 "November",
 "Desember");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Skift f�rste ukedag";
Calendar._TT["PREV_YEAR"] = "Et �r tilbake (hold for meny)";
Calendar._TT["PREV_MONTH"] = "En m�ned tilbake (hold for meny)";
Calendar._TT["GO_TODAY"] = "G� til i dag";
Calendar._TT["NEXT_MONTH"] = "En m�ned fram (hold for meny)";
Calendar._TT["NEXT_YEAR"] = "Et �r fram (hold for meny)";
Calendar._TT["SEL_DATE"] = "Velg dag";
Calendar._TT["DRAG_TO_MOVE"] = "Dra vinduet";
Calendar._TT["PART_TODAY"] = " (i dag)";
Calendar._TT["MON_FIRST"] = "Vis mandag f�rst";
Calendar._TT["SUN_FIRST"] = "Vis s�ndag f�rst";
Calendar._TT["CLOSE"] = "Lukk vinduet";
Calendar._TT["TODAY"] = "I dag";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "y-mm-dd";
Calendar._TT["TT_DATE_FORMAT"] = "D d. M, y";

Calendar._TT["WK"] = "wk";
