<?php
/**
 * This is an illustrative example of an external website that uses the limbas soap api to search for files stored in limbas
 */


# needed limbas folder and table ids
define('MAIN_FOLDER', 1);
define('LMB_FILES', 2);
define('LMB_FILE_ID', 1);

# limbas soap functionality (function call_client)
require('lib/include.lib');

# query params
$page = isset($_GET['page']) ? urldecode($_GET['page']) : 1;
$query = urldecode($_GET['query']);

# search input
$placeholder = $query ? '' : 'Versuche \'Linux\'';
$html = <<<EOD
        <div class="row justify-content-center">
            <h1>Dateisystem-Suche</h1>
        </div>
        <div class="row justify-content-center">
            <div class="col">
                <form class="form-inline">
                    <div class="input-group input-group-lg">
                        <input type="text" class="form-control" name="query" aria-label="Large" value="$query" placeholder="$placeholder">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">Los!</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
EOD;

# search results
if ($query) {
    $lmpar = array();
    $lmpar[0]['getvars'] = array('fresult');            # get results
    $lmpar[0]['action'] = 'explorer_main';              # get file explorer results
    $lmpar[0]['LID'] = MAIN_FOLDER;                     # of this folder

    $lmpar[0]['ffilter']['sub'] = true;                 # also search sub-folders
    $lmpar[0]['ffilter']['page'] = $page;               # start on this page
    $lmpar[0]['ffilter']['anzahl'] = 5;                 # return this many datasets
    $lmpar[0]['ffilter']['viewmode'][MAIN_FOLDER] = 2;  # view where the query was found in the contents of the file
    $lmpar[0]['ffilter']['content'] = $query;           # search for this
//    $lmpar[0]['ffilter']['content_ts'] = 1;             # search for part of the word

    # limbas soap call
    $result = call_client($lmpar);
    if (!$result || !array_key_exists(0, $result) || !array_key_exists('ffile', $result[0])) {
        $fileResult = false;
    } else {
        $fileResult = $result[0]['ffile'];
    }

    $maxPages = ceil($fileResult['max_count'] / 5);

    $html .= '<div class="row justify-content-center">';
    $html .= '    <div class="col">';
    $html .= '        <div class="list-group">';
    foreach ($fileResult['name'] as $fileID => $fileName) {
        $html .= '        <a class="list-group-item list-group-item-action flex-column align-items-start" onclick="selectFile(' . $fileID . ')">';
        $html .= '            <div class="d-flex w-100 justify-content-between mb-3">';
        $html .= '                <h5 class="mb-1">' . $fileName . '</h5>';
        $html .= '                <small>' . file_size($fileResult['size'][$fileID]) . '</small>';
        $html .= '            </div>';
        $html .= '            <p class="mb-1">' . $fileResult['context'][$fileID] . '</p>';
        $html .= '            <div class="d-flex w-100 justify-content-between mt-3">';
        $html .= '                <small>' . $fileResult['erstuser'][$fileID] . '</small>';
        $html .= '                <small>' . $fileResult['url'][$fileID] . '</small>';
        $html .= '                <small>' . $fileResult['ext'][$fileID] . '</small>';
        $html .= '                <small>' . $fileResult['erstdatum'][$fileID] . '</small>';
        $html .= '            </div>';
        $html .= '        </a>';
    }
    $html .= '        </div>';
    $html .= '    </div>';
    $html .= '</div>';
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Limbas SOAP Example</title>
    <meta name="description" content="Limbas SOAP Example">
    <meta name="author" content="Limbas">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
          integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style type="text/css">
        body {
            background-color: #a8bfde;
        }
        .input-group {
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }
        .input-group {
            transition: box-shadow 0.2s ease-in-out;
            border-radius: 0;
        }
        .input-group:hover {
            box-shadow: 0 7px 18px rgba(0,0,0,0.4);
        }
        html, body {
            height: 100%;
        }
        .form-inline .input-group {
            width: 100%;
        }
        .row {
            margin-bottom: 1em;
        }
    </style>
    <script type="text/javascript">
        function selectPage(pageNo) {
            document.forms[0].page.value = pageNo;
            document.forms[0].submit();
        }
        function selectFile(fileID) {
            document.forms[0].file.value = fileID;
            document.forms[0].submit();
        }
    </script>
</head>

<body>
<div class="container" style="height: 100%; padding:5%;">
    <form name="form1">
        <input type="hidden" name="page" value="<?= $page ?>" />
        <input type="hidden" name="query" value="<?= $query ?>" />
    </form>
    <?= $html ?>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            <?php
            # pagination
            for ($i = 1; $i <= $maxPages; $i++) {
                if ($page == $i) {
                    # current page
                    echo <<<EOD
                        <li class="page-item active">
                            <a class="page-link rounded-0">{$i}</a>
                        </li>
EOD;
                } else {
                    # other page
                    echo <<<EOD
                        <li class="page-item">
                            <a class="page-link rounded-0" onclick="selectPage('{$i}')">{$i}</a>
                        </li>
EOD;
                }
            }
            ?>
        </ul>
    </nav>
</div>

</body>
</html>