<?
$LIM["lmpath"] = "/var/www/html/openlimbas/dependent";
chdir($LIM["lmpath"]);

require_once("inc/include_db.lib");
require_once("lib/include.lib");
require_once("lib/session.lib");
require_once("extra/explorer/filestructure.lib");

$LIM["url"] = $umgvar["url"]."/";

?>
<img src="<?=$LIM["url"]?>pic/wait1.gif" style="position:absolute;left:50%;top:25%">
<?
flush();

get_filestructure();
$preview_link = preview_archive(array($ID),'html',$searchval);
?>
<script language="JavaScript">
document.location.href='<?=$LIM["url"].$preview_link[0]?>';
</SCRIPT>