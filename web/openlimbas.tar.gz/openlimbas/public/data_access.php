<?php
/**
 * This is an illustrative example of an external website that uses data inside limbas via soap
 */


/**
 * Returns the url to download a file stored in limbas
 * @param $fileID string the id of the file, as returned by limbas
 * @return string the download url
 */
function getDownloadUrl($fileID) {
    global $LIM;

    $requestUrl = urlencode(base64_encode('main.php?action=download&ID=' . $fileID));
    $key = urlencode(md5($LIM['key'] . $requestUrl));
    return "proxy.php?key=$key&url=$requestUrl";
}

# needed limbas table and field ids
define('LMB_ARTICLES', 23);
define('LMB_ARTICLE_ID', 1);
define('LMB_ARTICLE_NAME', 2);
define('LMB_ARTICLE_DESC', 3);
define('LMB_ARTICLE_TYPE', 4);
define('LMB_ARTICLE_PRICE', 5);
define('LMB_ARTICLE_PIC', 6);
define('LMB_ARTICLE_MWST', 8);

define('LMB_STR_CONTAINS', 1);

# limbas soap functionality (function call_client)
require('lib/include.lib');

# query params
$page = isset($_GET['page']) ? urldecode($_GET['page']) : 1;
$search = urldecode($_GET['search']);
$category = urldecode($_GET['category']);
$selectedArticleID = urldecode($_GET['article']);

$lmpar = array();
$lmpar[0]['getvars'] = array('fresult', 'gselect'); # get results and select-pool information
$lmpar[0]['action'] = 'gtab_erg';                   # get table results
$lmpar[0]['gtabid'] = LMB_ARTICLES;                 # from table articles
$lmpar[0][LMB_ARTICLES]['showfields'] = array(      # return the following fields
    LMB_ARTICLE_ID,
    LMB_ARTICLE_NAME,
    LMB_ARTICLE_DESC,
    LMB_ARTICLE_TYPE,
    LMB_ARTICLE_PRICE,
    LMB_ARTICLE_PIC,
    LMB_ARTICLE_MWST
);
$lmpar[0][LMB_ARTICLES]['res_next'] = $page;        # start on this page
$lmpar[0][LMB_ARTICLES]['count'] = 9;               # return this many datasets

# result filter
$gsr = array();
if ($search) { # search in name
    $gsr[LMB_ARTICLES][LMB_ARTICLE_NAME][0] = $search;
    $gsr[LMB_ARTICLES][LMB_ARTICLE_NAME]['txt'][0] = LMB_STR_CONTAINS;
}
if ($category) { # filter by category
    $gsr[LMB_ARTICLES][LMB_ARTICLE_TYPE][0] = $category;
}
if ($selectedArticleID) { # filter by article id
    $gsr[LMB_ARTICLES][LMB_ARTICLE_ID][0] = $selectedArticleID;
}
$lmpar[0]['gsr'] = $gsr;

# limbas soap call
$result = call_client($lmpar);
if (!$result || !array_key_exists(0, $result)) {
    $articleResult = false;
    $categoryResult = false;
} else {
    $articleResult = $result[0];
    $categoryResult = $result['gselect'][LMB_ARTICLES][LMB_ARTICLE_TYPE];
    # limbas caches environment variables in session
    if (!$categoryResult) {
        $categoryResult = $_SESSION['lmbs']['gselect'][LMB_ARTICLES][LMB_ARTICLE_TYPE];
    }
}
$maxPages = ceil($articleResult['result']['max_count'][LMB_ARTICLES] / 9);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Limbas SOAP Example</title>
    <meta name="description" content="Limbas SOAP Example">
    <meta name="author" content="Limbas">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
          integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style type="text/css">
        body {
            background-color: #a8bfde;
        }

        .card, nav.navbar, li.page-item {
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.15);
        }

        .card {
            transition: box-shadow 0.2s ease-in-out;
            border-radius: 0;
        }

        .card[onclick]:hover {
            box-shadow: 0 7px 18px rgba(0, 0, 0, 0.4);
        }

        a[onclick], .card[onclick]{
            cursor: pointer;
        }

        .secondaryColor {
            color: darkorange;
        }

    </style>
    <script type="text/javascript">
        function changeSearch() {
            document.forms[0].page.value = '';
            document.forms[0].article.value = '';
            document.forms[0].submit();
        }
        function selectPage(pageNo) {
            document.forms[0].page.value = pageNo;
            document.forms[0].submit();
        }

        function selectCategory(categoryName) {
            document.forms[0].page.value = '';
            document.forms[0].search.value = '';
            document.forms[0].category.value = categoryName;
            document.forms[0].article.value = '';
            document.forms[0].submit();
        }

        function selectArticle(articleID) {
            document.forms[0].article.value = articleID;
            document.forms[0].submit();
        }
    </script>
</head>

<body>
<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light justify-content-between mb-4">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand">Shop</a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item <?= $category ? '' : 'active' ?>">
                    <a class="nav-link" onclick="selectCategory(null);">Alle</a>
                </li>
                <?php
                if ($categoryResult) {
                    foreach ($categoryResult['val'] as $poolKey => $categoryName) {
                        echo '<li class="nav-item ' . ($category == $categoryName ? 'active' : '') . '">';
                        echo '    <a class="nav-link" onclick="selectCategory(\'' . $categoryName . '\');">' . $categoryName . '</a>';
                        echo '</li>';
                    }
                }
                ?>

            </ul>
            <form class="form-inline">
                <input type="hidden" name="page" value="<?= $page ?>">
                <input type="hidden" name="category" value="<?= $category ?>">
                <input type="hidden" name="article" value="<?= $selectedArticleID ?>">
                <input class="form-control mr-sm-2" type="search" onchange="changeSearch();" name="search" placeholder="Search"
                       value="<?= $search ? $search : '' ?>" aria-label="Search">
                <button class="btn btn-secondary btn-outline-primary" type="button" onclick="changeSearch();">Search
                </button>
            </form>
        </div>

    </nav>
        <?php
        if (!$articleResult) {
            echo <<<EOD
                <div class="row">
                    <div class="col">
                        <div class="alert alert-danger" role="alert">
                            Ein Fehler ist aufgetreten!
                        </div>
                    </div>
                </div>
EOD;

        } else if ($selectedArticleID) {
            $article = $articleResult['fresult'][LMB_ARTICLES][$selectedArticleID];
            $mwst = $article[LMB_ARTICLE_MWST] ? $article[LMB_ARTICLE_MWST] : '';

            $img = '';
            if (count($article[LMB_ARTICLE_PIC]['id']) > 0) {
                $img = '<img class="d-block w-100" src="' . getDownloadUrl($article[LMB_ARTICLE_PIC]['id'][0]) . '" alt="First slide">';
            }

            echo <<<EOD
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <ol class="card-header breadcrumb mb-0">
                                <li class="breadcrumb-item"><a onclick="selectCategory(null);">Artikel</a></li>
                                <li class="breadcrumb-item"><a onclick="selectCategory('{$article[LMB_ARTICLE_TYPE]}');">{$article[LMB_ARTICLE_TYPE]}</a></li>
                                <li class="breadcrumb-item active" aria-current="page">{$article[LMB_ARTICLE_NAME]}</li>
                            </ol>
                            <div class="card-body">
                                <h5 class="card-title mb-0">{$article[LMB_ARTICLE_NAME]}</h5>
                                <hr class="mb-0">
                                <div class="row mt-2">
                                    <div class="col-8">
                                        {$img}
                                    </div>
                                    <div class="col">
                                        <h2 class="secondaryColor">
                                            {$article[LMB_ARTICLE_PRICE]}
                                            <small class="text-muted">inkl. {$mwst} MwSt.</small>
                                        </h2>
                                        <p class="card-text">{$article[LMB_ARTICLE_DESC]}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer"></div>
                        </div>
                    </div>
                </div>
EOD;


        } else {
            echo '<div class="row">';
            foreach ($articleResult['fresult'][LMB_ARTICLES] as $article) {
                $img = '';
                if (count($article[LMB_ARTICLE_PIC]['id']) > 0) {
                    $img = '<img class="card-img-top" src="' . getDownloadUrl($article[LMB_ARTICLE_PIC]['id'][0]) . '" alt="Card image cap">';
                }
                echo <<<EOD
                    <div class="col-lg-4 col-md-4 mb-4">
                        <div class="card" onclick="selectArticle({$article[LMB_ARTICLE_ID]});">
                            {$img}
                            <div class="card-body">
                                <h5 class="card-title mb-0">{$article[LMB_ARTICLE_NAME]}</h5>
                                <h7 class="card-subtitle mb-0 text-muted">{$article[LMB_ARTICLE_TYPE]}</h7>
                                <hr>
                                <p class="card-text">{$article[LMB_ARTICLE_DESC]}</p>
                            </div>
                            <div class="card-footer text-right">{$article[LMB_ARTICLE_PRICE]}</div>
                        </div>
                    </div>
EOD;
            }
            echo '</div>';
        }

        ?>

    <?php if (!$selectedArticleID) { ?>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            <?php
            # pagination
            for ($i = 1; $i <= $maxPages; $i++) {
                if ($page == $i) {
                    # current page
                    echo <<<EOD
                        <li class="page-item active">
                            <a class="page-link rounded-0">{$i}</a>
                        </li>
EOD;
                } else {
                    # other page
                    echo <<<EOD
                        <li class="page-item">
                            <a class="page-link rounded-0" onclick="selectPage('{$i}')">{$i}</a>
                        </li>
EOD;
                }
            }
            ?>
        </ul>
    </nav>
    <?php } ?>
</div>

</body>
</html>